import { styled } from '@mui/material';
import { css } from '@emotion/react';
import { drawerWidth, headerHeight } from '@constants/header';

interface HeaderProps {
  open: boolean;
  children: React.ReactNode;
}

const MainContent = ({ open, children }: HeaderProps) => {
  return (
    <Main open={open} css={style}>
      <div className="offset" />
      {children}
    </Main>
  );
};

const style = css`
  .offset {
    height: ${headerHeight};
  }
`;

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })<{
  open?: boolean;
}>(({ theme, open }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  transition: theme.transitions.create('margin', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  marginLeft: `-${drawerWidth}px`,
  ...(open && {
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  }),
}));

export default MainContent;
