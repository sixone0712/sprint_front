export { default } from './MainContent';
