import { Box } from '@mui/material';
import { useState } from 'react';
import MainContent from './MainContent';
import MainDrawer from './MainDrawer';
import MainHeader from './MainHeader';

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout = ({ children }: MainLayoutProps) => {
  const [open, setOpen] = useState(false);

  const handleDrawerToggle = () => {
    setOpen((prev) => !prev);
  };

  return (
    <Box sx={{ display: 'flex', width: '100%' }}>
      <MainHeader open={open} handleDrawerToggle={handleDrawerToggle} />
      <MainDrawer open={open} handleDrawerToggle={handleDrawerToggle} />
      <MainContent open={open}>{children}</MainContent>
    </Box>
  );
};

export default MainLayout;
