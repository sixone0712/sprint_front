export { default } from './MainHeader';
