import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons';
import { Box, IconButton, styled, Toolbar, Typography, useMediaQuery, useTheme } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import MuiAppBar, { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import { css } from '@emotion/react';
import { drawerWidth, headerHeight } from '@constants/header';
import { grey } from '@mui/material/colors';

interface HeaderProps {
  open: boolean;
  handleDrawerToggle: () => void;
}

const MainHeader = ({ open, handleDrawerToggle }: HeaderProps) => {
  const theme = useTheme();
  const matchDownMD = useMediaQuery(theme.breakpoints.down('lg'));

  return (
    <AppBar position="fixed" open={open} css={style}>
      <Toolbar className="header__toolbar">
        <IconButton color="inherit" aria-label="open drawer" onClick={handleDrawerToggle} edge="start">
          <MenuIcon />
        </IconButton>
        {/* <Typography variant="h6" noWrap component="div">
          Persistent drawer
        </Typography> */}
      </Toolbar>
    </AppBar>
  );
};

const style = css`
  background-color: white;
  box-shadow: none;
  border-bottom: 1px solid ${grey[200]};
  color: ${grey[900]};
  .header__toolbar {
    padding: 0.5rem 1rem 0.5rem 1rem;
    min-height: ${headerHeight};
  }
`;

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})<AppBarProps>(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

export default MainHeader;
